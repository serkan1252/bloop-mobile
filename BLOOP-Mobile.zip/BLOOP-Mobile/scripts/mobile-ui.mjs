// Mobile-only presentation changes. The original game and save format stay intact.
export function mobileUi(html) {
  const replace = (before, after) => {
    if (!html.includes(before)) throw new Error('Mobile patch anchor missing: ' + before.slice(0, 70));
    html = html.replaceAll(before, after);
  };
  // Bound the transient effect budget and avoid repeated layout reads per particle.
  replace('indices.slice(0,20)', 'indices.slice(0,6)');
  replace('k<10;k++', 'k<3;k++');
  replace('targets.slice(0,24)', 'targets.slice(0,6)');
  replace('i<38;i++', 'i<12;i++');
  // Keep the 64 tile nodes mounted; selection no longer rebuilds the entire grid.
  replace("const frag=document.createDocumentFragment();game.board.forEach((tile,i)=>{const b=document.createElement('button');", "const board=$('board');game.board.forEach((tile,i)=>{const b=board.children[i]||document.createElement('button');b.style.transform='';b.style.zIndex='';");
  replace("const gem=document.createElement('span');gem.className='gem c'", "const gem=b.firstElementChild||document.createElement('span');gem.className='gem c'");
  replace("const detail=document.createElement('i');detail.className='detail';gem.appendChild(detail);b.appendChild(gem);frag.appendChild(b);});$('board').replaceChildren(frag);", "if(!gem.firstElementChild){const detail=document.createElement('i');detail.className='detail';gem.appendChild(detail);}if(!b.firstElementChild)b.appendChild(gem);if(!b.parentNode)board.appendChild(b);});");
  replace("if(busy&&target.dataset.action!=='close')", "if(busy&&!['close','soundSettings','previewSound','help'].includes(target.dataset.action))");
  replace("if(busy&&action!=='close')", "if(busy&&!['close','soundSettings','previewSound','help'].includes(action))");
  replace("if(focused!==undefined)$('board').children[Number(focused)]?.focus();", "if(focused!==undefined)$('board').children[Number(focused)]?.focus({preventScroll:true});");
  replace("$('close').focus();", "$('close').focus({preventScroll:true});");
  replace('previousFocus?.focus?.();', 'previousFocus?.focus?.({preventScroll:true});');
  replace("openModal('Ses atölyesi',", "openModal('Ayarlar',");
  replace('<div class="volume-panel"><label', '<div class="modal-actions"><button class="secondary" data-action="help">Kurallar</button><button class="secondary" data-action="powerLab">Güçleri dene</button><button class="secondary" data-action="daily">Günlük hediye</button><button class="secondary" data-action="mobileRestart">Yeniden oyna</button></div><div class="volume-panel"><label');
  replace("if(action==='soundSettings')soundSettings();", "if(action==='soundSettings')soundSettings();if(action==='mobileRestart')$('restart').onclick();");
  replace('<span id="wallet" class="pill">◇ 0</span>', '<button class="pill secondary" data-action="soundSettings" aria-label="Ayarlar">⚙ Ayarlar</button><span id="wallet" class="pill">◇ 0</span>');
  const pointerDown = html.match(/\$\('board'\)\.addEventListener\('pointerdown'[^\n]+/)[0];
  const pointerUp = html.match(/\$\('board'\)\.addEventListener\('pointerup'[^\n]+/)[0];
  replace(pointerDown, `let mobileDrag=null;
$('board').addEventListener('pointerdown',e=>{const b=e.target.closest('.tile');if(!b||busy||!$('overlay').hidden)return;pointerStart=Number(b.dataset.index);mobileDrag={x:e.clientX,y:e.clientY,index:pointerStart,id:e.pointerId,size:b.getBoundingClientRect().width};$('board').setPointerCapture(e.pointerId);});
$('board').addEventListener('pointermove',e=>{if(!mobileDrag||e.pointerId!==mobileDrag.id)return;const dx=e.clientX-mobileDrag.x,dy=e.clientY-mobileDrag.y,b=$('board').children[mobileDrag.index];if(b){b.style.transform='translate('+Math.max(-mobileDrag.size/2,Math.min(mobileDrag.size/2,dx))+'px,'+Math.max(-mobileDrag.size/2,Math.min(mobileDrag.size/2,dy))+'px)';b.style.zIndex='4';}});`);
  replace(pointerUp, `$('board').addEventListener('pointerup',e=>{const drag=mobileDrag;mobileDrag=null;pointerStart=-1;if(!drag)return;const b=$('board').children[drag.index];if(b){b.style.transform='';b.style.zIndex='';}const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.max(Math.abs(dx),Math.abs(dy))<Math.max(10,drag.size*.25)){suppressClickUntil=Date.now()+500;select(drag.index);return;}e.preventDefault();suppressClickUntil=Date.now()+500;const horizontal=Math.abs(dx)>Math.abs(dy),step=horizontal?(dx>0?1:-1):(dy>0?8:-8),target=drag.index+step;if(game.adjacent(drag.index,target))move(drag.index,target);});`);
  replace("$('board').addEventListener('pointercancel',()=>pointerStart=-1);", "$('board').addEventListener('pointercancel',()=>{pointerStart=-1;if(mobileDrag){const b=$('board').children[mobileDrag.index];if(b){b.style.transform='';b.style.zIndex='';}}mobileDrag=null;});");
  return html.replace('</head>', `<style id="bloop-mobile-layout">
html,body{width:100%;max-width:100%;margin:0}button{-webkit-appearance:none;appearance:none;touch-action:manipulation}
.center,.heading>div,.stat,.tile{min-width:0}.tile{min-height:0}.board{grid-template-columns:repeat(8,minmax(0,1fr))}
/* WKWebView can resolve a grid child's percentage height to zero. Anchor gems to the square tile instead. */
.tile>.gem{position:absolute;inset:6%;width:auto;height:auto}.tile>.gem.c1{inset:14%;width:auto;height:auto}
.scenery *,.gem,.gem::before,.gem::after,.gem .detail{animation:none!important}.gem,.gem::before,.gem .detail{filter:none!important}
.tile{perspective:none}.card,.overlay{backdrop-filter:none;-webkit-backdrop-filter:none}
.reactor-core,.reactor-grid,.plasma-orbit,.electric-link,.micro-flare,.impact-glow{display:none!important}
.impact-core{width:36px;height:36px;mix-blend-mode:normal;animation-duration:.22s;background:radial-gradient(circle,#fff 0 8%,var(--theme-glow) 24%,transparent 65%)}
.board-wrap.impact-small,.board-wrap.impact-big{animation:none!important}
.overlay{z-index:1000;padding:12px}.modal{max-height:calc(100dvh - 24px);overscroll-behavior:contain}.modal-head{gap:8px}.modal h2{min-width:0;font-size:23px}.close{flex:0 0 44px;height:44px}.modal-actions{flex-wrap:wrap}.volume-panel input{width:100%;min-width:0}
@media(max-width:700px){
.layout{padding:8px 10px 14px;max-width:480px}.topline{gap:6px;margin:0 0 8px;flex-wrap:wrap}.pill{font-size:12px;padding:9px 10px;min-height:40px}
.heading h1{font-size:23px}.heading .kicker{font-size:9px;letter-spacing:.5px;overflow-wrap:anywhere}.theme-caption{font-size:10px;margin-top:2px}.flower{width:36px;height:36px;font-size:25px}
.stats{grid-template-columns:minmax(0,1fr) minmax(0,1.5fr) minmax(0,1fr);margin:9px 0 10px;gap:6px}.stat{padding:6px 2px;border-radius:12px}.stat label{font-size:8px;letter-spacing:.6px}.stat strong{font-size:20px;margin-top:3px}.stat.goal strong{font-size:13px}.bar{height:6px;margin-top:5px}
.board-wrap{width:min(100%,max(260px,calc(100dvh - 285px)));margin-inline:auto;padding:6px;border-width:2px;border-radius:18px;box-shadow:inset 0 2px #ffffff80,inset -2px -4px #11152b,0 5px #160d2b,0 7px var(--theme-frame)}.board{gap:3px;padding:3px}.tile{padding:2px;border-radius:7px;box-shadow:inset 0 2px 3px #03081780,inset 0 -1px #c397fc30}.gem{box-shadow:inset 2px 3px 1px #ffffffb0,inset -3px -5px 2px var(--rim),inset 0 -8px 5px #0003,0 3px 1px #05091aaa}.gem .detail{box-shadow:inset 0 1px 2px #ffffff70!important}.gem::before{opacity:1;background:linear-gradient(180deg,#fff,#ffffff80);box-shadow:0 1px 0 #ffffff50}.gem.special{outline:1px solid #fff9;outline-offset:1px}.gem.special::after{font-size:18px;text-shadow:0 2px 2px #271137,0 0 3px #fff6}
.tile.selected{box-shadow:inset 0 2px #fff8,0 0 8px #ffd66799}.tile.jelly{box-shadow:inset 0 2px #ffe4f799,inset 0 -3px #95227780}.impact-ring{box-shadow:0 0 5px var(--theme-glow);border-width:2px}.candy-shard{box-shadow:0 0 3px var(--color),0 1px 1px #0008}.score-float{text-shadow:0 2px #84156d,1px 0 #84156d,-1px 0 #84156d;font-size:25px}.power-beam{box-shadow:0 0 8px #41d9ff}.power-rainbow{box-shadow:inset 0 0 12px #24dcff,inset 0 0 24px #b14eff66}
.feedback{height:35px;font-size:14px;text-align:center}.tools{gap:6px}.tool{min-width:0;padding:6px 2px;min-height:48px;font-size:10px}.tool b{font-size:19px;margin-bottom:2px}
.footnote{display:none}.volume-panel{margin-top:16px}.modal-actions .secondary{min-height:44px}
.level-grid{gap:8px;grid-template-columns:repeat(5,minmax(0,1fr))}.level{min-width:0;min-height:60px;font-size:18px}.modal{padding:16px}.toast{z-index:1100}
}
@media(max-height:650px) and (max-width:700px){.theme-caption,.flower{display:none}.heading h1{margin:2px 0}.feedback{height:29px}.topline{margin-bottom:5px}.stats{margin:6px 0 8px}}
</style></head>`);
}
